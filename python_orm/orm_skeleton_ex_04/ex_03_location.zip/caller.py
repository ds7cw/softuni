import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models here

from main_app.models import Pet, Artifact, Location


# Create queries within functions

def create_pet(name: str, species: str): # 01
    Pet.objects.create(name=name, species=species)

    return f'{name} is a very cute {species}!'


def create_artifact(name: str, origin: str, age: int, description: str, is_magical: bool): # 02
    Artifact.objects.create(name=name,
                            origin=origin,
                            age=age,
                            description=description,
                            is_magical=is_magical)
    
    return f'The artifact {name} is {age} years old!'


def delete_all_artifacts(): # 02
    Artifact.objects.all().delete()


def show_all_locations(): # 03
    result = []
    locations = Location.objects.all().order_by('-id')

    for location in locations:
        result.append(f'{location.name} has a population of {location.population}!')

    return '\n'.join(result)


def new_capital(): # 03
    first_location = Location.objects.first()
    first_location.is_capital = True
    first_location.save()


def get_capitals(): # 03
    result = Location.objects.filter(is_capital=True).values('name')
    return result

def delete_first_location(): # 03
    Location.objects.first().delete()


# 01
# print(create_pet('Buddy', 'Dog'))
# print(create_pet('Whiskers', 'Cat'))
# print(create_pet('Rocky', 'Hamster'))


# 02
# print(create_artifact('Ancient Sword', 'Lost Kingdom', 500,
#     'A legendary sword with a rich history', True))

# print(create_artifact('Crystal Amulet', 'Mystic Forest', 300,
#     'A magical amulet believed to bring good fortune', True))


# 03
my_data = [
    ['Sofia', 'Sofia Region', 1329000, 'The capital of Bulgaria and the largest city in the country', False],
    ['Plovdiv', 'Plovdiv Region',	346942,	'The second-largest city in Bulgaria with a rich historical heritage', False],
    ['Varna', 'Varna Region', 330486, 'A city known for its sea breeze and beautiful beaches on the Black Sea', False]
]
for idx, record in enumerate(my_data):
    location_data = [idx] + record
    current_location = Location(*location_data)
    current_location.save()

print(show_all_locations())
print(new_capital())
print(get_capitals())
