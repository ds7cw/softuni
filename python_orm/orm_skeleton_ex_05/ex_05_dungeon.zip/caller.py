import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models
from main_app.models import ArtworkGallery, Laptop, ChessPlayer, Meal, Dungeon
# Create and check models
# Run and print your queries


def show_highest_rated_art() -> str: # 01
    highest_rated_art = ArtworkGallery.objects.order_by('-rating', 'id').first()
    return f"{highest_rated_art.art_name} is the highest-rated art with a {highest_rated_art.rating} rating!"


def bulk_create_arts(first_art, second_art) -> None: # 01
    ArtworkGallery.objects.bulk_create([first_art, second_art])


def delete_negative_rated_arts() -> None: # 01
    ArtworkGallery.objects.filter(rating__lt=0).delete()


def show_the_most_expensive_laptop() -> str: # 02
    laptop = Laptop.objects.order_by('-price', '-id').first()
    return f"{laptop.brand} is the most expensive laptop available for {laptop.price}$!"


def bulk_create_laptops(*args) -> None: # 02
    Laptop.objects.bulk_create(*args)


def update_to_512_GB_storage() -> None: # 02
    Laptop.objects.filter(brand__in=['Asus', 'Lenovo']).update(storage=512)


def update_to_16_GB_memory() -> None: # 02
    Laptop.objects.filter(brand__in=['Apple', 'Dell', 'Acer']).update(memory=16)


def update_operation_systems() -> None: # 02
    for laptop in Laptop.objects.all():
        if laptop.brand == 'Asus':
            laptop.operation_system = 'Windows'
        elif laptop.brand == 'Apple':
            laptop.operation_system = 'MacOS'
        elif laptop.brand in ['Dell', 'Acer']:
            laptop.operation_system = 'Linux'
        elif laptop.brand == 'Lenovo':
            laptop.operation_system = 'Chrome OS'
        laptop.save()


def delete_inexpensive_laptops() -> None: # 02
    Laptop.objects.filter(price__lt=1200).delete()


def bulk_create_chess_players(*args) -> None: # 03
    ChessPlayer.objects.bulk_create(*args)


def delete_chess_players() -> None: # 03
    ChessPlayer.objects.filter(title='no title').delete()


def change_chess_games_won() -> None: # 03
    ChessPlayer.objects.filter(title='GM').update(games_won=30)


def change_chess_games_lost() -> None: # 03
    ChessPlayer.objects.filter(title='no title').update(games_lost=25)


def change_chess_games_drawn() -> None: # 03
    ChessPlayer.objects.all().update(games_drawn=10)


def grand_chess_title_GM() -> None: # 03
    ChessPlayer.objects.filter(rating__gte=2400).update(title='GM')


def grand_chess_title_IM() -> None: # 03
    ChessPlayer.objects.filter(rating__range=(2300, 2399)).update(title='IM')


def grand_chess_title_FM() -> None: # 03
    ChessPlayer.objects.filter(rating__range=(2200, 2299)).update(title='FM')


def grand_chess_title_regular_player() -> None: # 03
    ChessPlayer.objects.filter(rating__range=(0, 2199)).update(title='regular player')


def set_new_chefs() -> None: # 04
    meal_chef_dict = {'Breakfast': 'Gordon Ramsay',
                      'Lunch': 'Julia Child',
                      'Dinner': 'Jamie Oliver',
                      'Snack': 'Thomas Keller'}

    for meal_key, chef_value in meal_chef_dict.items():
        Meal.objects.filter(meal_type=meal_key).update(chef=chef_value)


def set_new_preparation_times() -> None: # 04
    meal_prep_dict = {'Breakfast': '10 minutes',
                      'Lunch': '12 minutes',
                      'Dinner': '15 minutes',
                      'Snack': '5 minutes'}
        
    for meal_key, prep_time_value in meal_prep_dict.items():
        Meal.objects.filter(meal_type=meal_key).update(preparation_time=prep_time_value)


def update_low_calorie_meals() -> None: # 04
    Meal.objects.filter(meal_type__in=['Breakfast', 'Dinner']).update(calories=400)


def update_high_calorie_meals() -> None: # 04
    Meal.objects.filter(meal_type__in=['Lunch', 'Snack']).update(calories=700)


def delete_lunch_and_snack_meals() -> None: # 04
    Meal.objects.filter(meal_type__in=['Lunch', 'Snack']).delete()


def show_hard_dungeons() -> str: # 05
    hard_dungeons = Dungeon.objects.filter(difficulty='Hard').order_by('-location')
    result = '\n'.join([f'{dungeon.name} is guarded by {dungeon.boss_name} who has {dungeon.boss_health} health points!' for dungeon in hard_dungeons])
    return result


def bulk_create_dungeons(*args) -> None: # 05
    Dungeon.objects.bulk_create(*args)


def update_dungeon_names() -> None: # 05
    Dungeon.objects.filter(difficulty='Easy').update(name='The Erased Thombs')
    Dungeon.objects.filter(difficulty='Medium').update(name='The Coral Labyrinth')
    Dungeon.objects.filter(difficulty='Hard').update(name='The Lost Haunt')


def update_dungeon_bosses_health() -> None: # 05
    Dungeon.objects.exclude(difficulty='Easy').update(boss_health=500)


def update_dungeon_recommended_levels() -> None: # 05
    Dungeon.objects.filter(difficulty='Easy').update(recommended_level=25)
    Dungeon.objects.filter(difficulty='Medium').update(recommended_level=50)
    Dungeon.objects.filter(difficulty='Hard').update(recommended_level=75)


def update_dungeon_rewards() -> None: # 05
    Dungeon.objects.filter(boss_health=500).update(reward='1000 Gold')
    Dungeon.objects.filter(location__istartswith='E').update(reward='New dungeon unlocked')
    Dungeon.objects.filter(location__iendswith='s').update(reward='Dragonheart Amulet')


def set_new_locations() -> None: # 05
    level_location_dict = {25: 'Enchanted Maze',
                           50: 'Grimstone Mines',
                           75: 'Shadowed Abyss'}
    
    for level_key, location_value in level_location_dict.items():
        Dungeon.objects.filter(recommended_level=level_key).update(location=location_value)






# 01
# artwork1 = ArtworkGallery(artist_name="Vincent van Gogh", art_name="Starry Night", rating=4, price=1200000.0)
# artwork2 = ArtworkGallery(artist_name="Leonardo da Vinci", art_name="Mona Lisa", rating=5, price=1500000.0)

# # Bulk saves the instances
# bulk_create_arts(artwork1, artwork2)
# print(show_highest_rated_art())
# print(ArtworkGallery.objects.all())


# 02
# # Create three instances of Laptop
# laptop1 = Laptop(
#     brand='Asus',
#     processor='Intel Core i5',
#     memory=8,
#     storage=256,
#     operation_system='Windows',
#     price=899.99
# )

# laptop2 = Laptop(
#     brand='Apple',
#     processor='Apple M1',
#     memory=16,
#     storage=512,
#     operation_system='MacOS',
#     price=1399.99

# )

# laptop3 = Laptop(
#     brand='Lenovo',
#     processor='AMD Ryzen 7',
#     memory=12,
#     storage=512,
#     operation_system='Linux',
#     price=999.99,
# )

# # Create a list of instances
# laptops_to_create = [laptop1, laptop2, laptop3]

# # Use bulk_create to save the instances
# # bulk_create_laptops(laptops_to_create)

# # Execute the following functions
# update_to_512_GB_storage()
# update_operation_systems()

# # Retrieve 2 laptops from the database
# asus_laptop = Laptop.objects.filter(brand__exact='Asus').get()
# lenovo_laptop = Laptop.objects.filter(brand__exact='Lenovo').get()

# print(asus_laptop.storage)
# print(lenovo_laptop.operation_system)


# 03
# # Create two instances of ChessPlayer
# player1 = ChessPlayer(
#     username='Player1',
#     title='no title',
#     rating=2200,
#     games_played=50,
#     games_won=20,
#     games_lost=25,
#     games_drawn=5,
# )

# player2 = ChessPlayer(
#     username='Player2',
#     title='IM',
#     rating=2350,
#     games_played=80,
#     games_won=40,
#     games_lost=25,
#     games_drawn=15,
# )

# # Call the bulk_create_chess_players function
# bulk_create_chess_players([player1, player2])

# # Call the delete_chess_players function
# delete_chess_players()

# # Check that the players are deleted
# print("Number of Chess Players after deletion:", ChessPlayer.objects.count())


# 04
# # Create two instances of the Meal model
# meal1 = Meal.objects.create(
#     name="Pancakes",
#     meal_type="Breakfast",
#     preparation_time="20 minutes",
#     difficulty=3,
#     calories=350,
#     chef="Jane",
# )

# meal2 = Meal.objects.create(
#     name="Spaghetti Bolognese",
#     meal_type="Dinner",
#     preparation_time="45 minutes",
#     difficulty=4,
#     calories=550,
#     chef="Sarah",
# )
# # Test the set_new_chefs function
# set_new_chefs()

# # Test the set_new_preparation_times function
# set_new_preparation_times()

# # Refreshes the instances 
# meal1.refresh_from_db()
# meal2.refresh_from_db()

# # Print the updated meal information
# print("Meal 1 Chef:", meal1.chef)
# print("Meal 1 Preparation Time:", meal1.preparation_time)
# print("Meal 2 Chef:", meal2.chef)
# print("Meal 2 Preparation Time:", meal2.preparation_time)


# 05
# # Create two instances
# dungeon1 = Dungeon(
#     name="Dungeon 1",
#     boss_name="Boss 1",
#     boss_health=1000,
#     recommended_level=75,
#     reward="Gold",
#     location="Eternal Hell",
#     difficulty="Hard",
# )

# dungeon2 = Dungeon(
#     name="Dungeon 2",
#     boss_name="Boss 2",
#     boss_health=500,
#     recommended_level=25,
#     reward="Experience",
#     location="Crystal Caverns",
#     difficulty="Easy",
# )

# # Bulk save the instances
# bulk_create_dungeons([dungeon1, dungeon2])

# # Update boss's health
# update_dungeon_bosses_health()

# # Show hard dungeons
# hard_dungeons_info = show_hard_dungeons()
# print(hard_dungeons_info)

# # Change dungeon names based on difficulty
# update_dungeon_names()
# dungeons = Dungeon.objects.all()
# print(dungeons[0].name)
# print(dungeons[1].name)

# # Change the dungeon rewards
# update_dungeon_rewards()
# dungeons = Dungeon.objects.all()
# print(dungeons[0].reward)
# print(dungeons[1].reward)
