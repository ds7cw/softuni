import os
import django
from datetime import date

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models
from main_app.models import Student

# Create and check models
def add_students():
    my_data = [
            ['FC5204', 'John', 'Doe', '15/05/1995', 'john.doe@university.com'],
            ['FE0054', 'Jane', 'Smith', '',	'jane.smith@university.com'],
            ['FH2014', 'Alice', 'Johnson', '10/02/1998', 'alice.johnson@university.com'],
            ['FH2015', 'Bob', 'Wilson', '25/11/1996', 'bob.wilson@university.com'],
        ]
    
    for record in my_data:
        if record[3]:
            day, month, year = record[3].split('/')
            record[3] = '-'.join([year, month, day])
        else:
            record[3] = None

        current_student = Student(*record)
        current_student.save() 
    # print(f'{len(some_data)} records created successfully!')


def get_students_info():
    students = Student.objects.all()
    result = []

    for student in students:
        result.append(f'Student №{student.student_id}: {student.first_name} {student.last_name}; Email: {student.email}') 

    return '\n'.join(result)

# Run and print your queries
# add_students()
# print(Student.objects.all())

print(get_students_info())