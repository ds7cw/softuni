import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()


# Import your models here
from main_app.models import Profile, Product, Order

from django.db.models import Q, F, Count
# Create and run your queries within functions


def get_profiles(search_string=None): # 04
    result = []

    if search_string is not None:
        query = Q(full_name__icontains=search_string) | Q(email__icontains=search_string) | Q(phone_number__icontains=search_string)
        profiles = Profile.objects.prefetch_related('orders').annotate(order_count=Count('orders')).filter(query).order_by('full_name')

        for profile in profiles:
            result.append(f'Profile: {profile.full_name}, email: {profile.email}, phone number: {profile.phone_number}, orders: {profile.order_count}')

    return '\n'.join(result) if result else ''


def get_loyal_profiles(): # 04
    profiles = Profile.objects.prefetch_related('orders').annotate(order_count=Count('orders')).filter(order_count__gt=2).order_by('-order_count')
    result = []
    for profile in profiles:
        result.append(f'Profile: {profile.full_name}, orders: {profile.order_count}')

    return '\n'.join(result)


def get_last_sold_products(): # 04
    if not Order.objects.all():
        return ''
    
    last_order = Order.objects.last()
    last_order_id = last_order.id
    last_order_products = Product.objects.prefetch_related('orders').filter(orders__id=last_order_id).order_by('name')

    return f'Last sold products: {", ".join([prod.name for prod in last_order_products])}' if last_order_products else ''


def get_top_products(): # 05
    result = ['Top products:']

    products = Product.objects.prefetch_related('orders').annotate(count_orders=Count('orders')).filter(count_orders__gt=0).order_by('-count_orders', 'name')[:5]

    for product in products:
        result.append(f'{product.name}, sold {product.count_orders} times')

    return '\n'.join(result) if len(result) > 1 else ''


def apply_discounts(): # 05
    query = Q(num_products__gt=2) & Q(is_completed=False)

    orders = Order.objects.prefetch_related('products').annotate(num_products=Count('products')).filter(query)
    orders.update(total_price=F('total_price') * 0.9)

    updated_orders = orders.count()

    return f'Discount applied to {updated_orders} orders.'


def complete_order(): # 05
    earliest_incomplete = Order.objects.prefetch_related('products').filter(is_completed=False).order_by('creation_date').first()

    if earliest_incomplete is None:
        return ''
    
    for product in earliest_incomplete.products.all():

        product.in_stock -= 1
        if product.in_stock == 0:
            product.is_available = False
        
        product.save()

    earliest_incomplete.is_completed=True
    earliest_incomplete.save()

    return "Order has been completed!"


def alternative_solutions_and_populate_models():
    # def apply_discounts2():
    #     orders = Order.objects.filter(productscountgt=2, is_completed=False)
    #     num_of_updated_orders = orders.update(total_price=F('total_price') * Decimal('0.90'))

    #     return f"Discount applied to {num_of_updated_orders} orders."

    # def complete_order2():
    #     order = Order.objects.filter(is_completed=False).order_by('creation_date').first()

    #     if order:
    #         products = order.products.all()
    #         for product in products:
    #             product.in_stock -= 1
                
    #             if product.in_stock == 0:
    #                 product.is_available = False
    #             product.save()

    #         order.is_completed = True
    #         order.save()
    #         return "Order has been completed!"
        
    #     else:
    #         return ""


    # Create models below:

    # prof1 = Profile.objects.create(
    #     full_name= 'Chris Paul',
    #     email= 'chris.paul@nba.com',
    #     phone_number= '123123123',
    #     address= '1 Park Drive'
    # )

    # prof2 = Profile.objects.create(
    #     full_name= 'Ben Wallace',
    #     email= 'ben.wallace@nba.com',
    #     phone_number= '321321321',
    #     address= '1 George Street'
    # )


    # prod1 = Product.objects.create(
    #     name = 'basketball',
    #     description = 'ball',
    #     price = 20,
    #     in_stock = 10
    # )

    # prod2 = Product.objects.create(
    #     name = 'backboard',
    #     description = 'part from the basket',
    #     price = 50,
    #     in_stock = 12
    # )


    # ord1 = Order.objects.create(
    #     profile = Profile.objects.first(),
    #     total_price = 40
    # )

    # ord2 = Order.objects.create(
    #     profile = Profile.objects.first(),
    #     total_price = 100
    # )


    # ord3 = Order.objects.create(
    #     profile = Profile.objects.last(),
    #     total_price = 20
    # )

    # ord4 = Order.objects.create(
    #     profile = Profile.objects.first(),
    #     total_price = 60
    # )

    # ord1.products.set([Product.objects.first()])
    # ord2.products.set([Product.objects.last()])
    # ord3.products.set([Product.objects.first()])
    # ord4.products.set([Product.objects.first(), Product.objects.last()])

    # print(Product.objects.all())
    # print(Order.objects.all())


    # print(Profile.objects.get_regular_customers())




    # print(get_profiles('a'))
    # Profile: Ben Wallace, email: ben.wallace@nba.com, phone number: 321321321, orders: 1
    # Profile: Chris Paul, email: chris.paul@nba.com, phone number: 123123123, orders: 2  

    # print(get_loyal_profiles())
    # Profile: Chris Paul, orders: 3

    # print(get_last_sold_products())

    # for prod in Product.objects.all():
    #     print(f'Name: {prod.name}, Descr: {prod.description}')

    # print(get_profiles())
    # print(get_loyal_profiles())
    # print(get_last_sold_products())


    # for order in Order.objects.all():
    #     print('---  --- ---')
    #     print(order.creation_date, order.id)

    #     for product in order.products.all():
    #         print(product.name, product.description, product.id)
        
    #     print('---  --- ---')
    #     print()

    # qqq = Q(num_products__gt=1) & Q(is_completed=False)
    # for order in Order.objects.prefetch_related('products').annotate(num_products=Count('products')).filter(qqq):

    #     print(f'Order #{order.id}')
    #     print(f'Number of Products: {order.products.count()}')
    #     print()

    # Order #1
    # Number of Products: 1

    # Order #2
    # Number of Products: 1

    # Order #3
    # Number of Products: 1

    # Order #4
    # Number of Products: 2
    pass
