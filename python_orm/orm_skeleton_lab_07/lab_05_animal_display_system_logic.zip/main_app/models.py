from django.db import models
from django.core.exceptions import ValidationError

# Create your models here.
# 01
class Animal(models.Model):
    
    name = models.CharField(max_length=100)
    species = models.CharField(max_length=100)
    birth_date = models.DateField()
    sound = models.CharField(max_length=100)


class Mammal(Animal):

    fur_color = models.CharField(max_length=50)


class Bird(Animal):

    wing_span = models.DecimalField(max_digits=5, decimal_places=2)


class Reptile(Animal):

    scale_type = models.CharField(max_length=50)


# 02
class Employee(models.Model):

    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    phone_number = models.CharField(max_length=10)

    class Meta:
        abstract = True


class ZooKeeper(Employee):
    
    CHOICES=(
        ('M', 'Mammals'),
        ('B','Birds'),
        ('R', 'Reptiles'),
        ('O', 'Others'),)

    specialty = models.CharField(max_length=10, choices=CHOICES)
    managed_animals = models.ManyToManyField(to='Animal')

    # 04
    def clean(self) -> None:
        super().clean()

        choices = [choice[1] for choice in self.CHOICES]
        if self.specialty not in choices:
            raise ValidationError(
                'Specialty must be a valid choice.'
            )


class Veterinarian(Employee):

    license_number = models.CharField(max_length=10)


# 03
class ZooDisplayAnimal(Animal):
    
    # 05
    def display_info(self) -> str:
        extra_info = ''

        if hasattr(self, 'mammal'):
            extra_info = f" Its fur color is {self.mammal.fur_color}."
        elif hasattr(self, 'bird'):
            extra_info = f" Its wingspan is {self.bird.wing_span} cm."
        elif hasattr(self, 'reptile'):
            extra_info = f" Its scale type is {self.reptile.scale_type}."

        return f"Meet {self.name}! It's {self.species} and it's born {self.birth_date}. It makes a noise like '{self.sound}'!{extra_info}"

    def is_endangered(self):
        if self.species in ['Cross River Gorilla', 'Orangutan', 'Green Turtle']:
            return True
        return False

    # 03
    class Meta:
        proxy = True
