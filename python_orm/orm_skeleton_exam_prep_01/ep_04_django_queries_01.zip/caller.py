import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models here
from main_app.models import Director, Actor, Movie
from django.db.models import Q, F, Count, Avg

# Create and run your queries within functions

def get_directors(search_name=None, search_nationality=None):
    result = []
    query = Q()

    if search_name is None and search_nationality is None:
        return ''
    
    if search_name is not None and search_nationality is not None:
        query = Q(full_name__icontains=search_name) & Q(nationality__icontains=search_nationality)

    elif search_name is None:
        query = Q(nationality__icontains=search_nationality)

    else:
        query = Q(full_name__icontains=search_name)

    directors = Director.objects.filter(query).order_by('full_name')

    for d in directors:
        result.append(f'Director: {d.full_name}, nationality: {d.nationality}, experience: {d.years_of_experience}')

    return '\n'.join(result)


# print(Director.objects.all())
# print(get_directors(search_nationality='B'))


def get_top_director():
    top_dir = Director.objects.get_directors_by_movies_count().first()

    return f'Top Director: {top_dir.full_name}, movies: {top_dir.movies_count}.' if top_dir else ''


def get_top_actor():

    top_actor = Actor.objects.prefetch_related('movies').annotate(
        stars_count=Count('movies__starring_actor')        
    ).order_by(
        '-stars_count', 'full_name'
    ).first()

    if not top_actor:
        return ''

    movies_starred_in = Movie.objects.filter(starring_actor=top_actor)

    if not movies_starred_in:
        return ''
    
    movies_avg_rating = movies_starred_in.aggregate(avg_rating=Avg('rating'))['avg_rating']
    movie_titles = [m.title for m in movies_starred_in]
    
    return f'Top Actor: {top_actor.full_name}, starring in movies: {", ".join(movie_titles)}, movies average rating: {movies_avg_rating:.1f}'



# from django.db.models import Q, Count, Avg from movies.models import Director, Actor, Movie
# def get_directors(search_name=None, search_nationality=None): if search_name is not None and search_nationality is not None: directors = Director.objects.filter( Q(full_name__icontains=search_name) & Q(nationality__icontains=search_nationality) ) elif search_name is not None: directors = Director.objects.filter(full_name__icontains=search_name) elif search_nationality is not None: directors = Director.objects.filter(nationality__icontains=search_nationality) else: return ""

# directors = directors.order_by('full_name')

# if directors.exists(): director_info = "" for director in directors: director_info += f"Director: {director.full_name}, nationality: {director.nationality}, experience: {director.years_of_experience}\n" return director_info else: return ""

# def get_top_director(): top_director = Director.objects.annotate(num_of_movies=Count('movie')).order_by('-num_of_movies', 'full_name').first()

# if top_director is not None: return f"Top Director: {top_director.full_name}, movies: {top_director.num_of_movies}" else: return ""

# def get_top_actor():
#     top_actor = Actor.objects.annotate(num_of_movies=Count('movie')).order_by('-num_of_movies', 'full_name').first()
#     if top_actor is not None:
    
#         movie_titles = top_actor.movie.values_list('title', flat=True)
    
#         movies_avg_rating = top_actor.movie.aggregate(avg_rating=Avg('rating'))['avg_rating']
    
#         movies_avg_rating = round(movies_avg_rating, 1)
    
#         movie_titles_str = ', '.join(movie_titles)
    
#         return f'Top Actor: {top_actor.full_name}, starring in movies: {movie_titles_str}, movies average rating: {movies_avg_rating}'
    
#     else: return ""





# It retrieves the starring actor with the greatest number of movies s/he starred in.
# If there is more than one actor with the same number of movies, order them by full name, ascending, and return the first one’s info.
# Return a string in the following format:
# "Top Actor: {actor_full_name}, starring in movies: {movie_title1}, {movie_title2}, … {movie_titleN}, movies average rating: {movies_avg_rating}"
# o	Movie titles must be separated by a comma and space (", ")
# o	Average rating represents the average value of the ratings from the movies in which the actor stars. Format it to the first decimal place.
# o	If there are no movies and/or no starring actors, return an empty string ("")


# Actor.objects.create(
#     full_name='Christian Bale',
#     birth_date='1974-01-30',
#     nationality='British'
# )

# actor1 = Actor.objects.first()
# print(actor1.full_name)
# print(actor1.is_awarded)
# actor1.is_awarded=False
# actor1.save()
# actor1.is_awarded