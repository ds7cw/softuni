from django.db import models


class CustomModelManager(models.Manager):
    def get_directors_by_movies_count(self):
        return self.prefetch_related('movies').annotate(
            movies_count=models.Count('movies')).order_by(
                '-movies_count', 'full_name'
            )