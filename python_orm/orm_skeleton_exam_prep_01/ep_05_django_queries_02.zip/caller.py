import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models here
from main_app.models import Director, Actor, Movie
from django.db.models import Q, F, Count, Avg


from decimal import Decimal

# Create and run your queries within functions

def get_directors(search_name=None, search_nationality=None): # 04
    result = []
    query = Q()

    if search_name is None and search_nationality is None:
        return ''
    
    if search_name is not None and search_nationality is not None:
        query = Q(full_name__icontains=search_name) & Q(nationality__icontains=search_nationality)

    elif search_name is None:
        query = Q(nationality__icontains=search_nationality)

    else:
        query = Q(full_name__icontains=search_name)

    directors = Director.objects.filter(query).order_by('full_name')

    for d in directors:
        result.append(f'Director: {d.full_name}, nationality: {d.nationality}, experience: {d.years_of_experience}')

    return '\n'.join(result)


# print(Director.objects.all())
# print(get_directors(search_nationality='B'))


def get_top_director(): # 04
    top_dir = Director.objects.get_directors_by_movies_count().first()

    return f'Top Director: {top_dir.full_name}, movies: {top_dir.movies_count}.' if top_dir else ''


def get_top_actor(): # 04

    top_actor = Actor.objects.prefetch_related('movies').annotate(
        stars_count=Count('movies__starring_actor')        
    ).order_by(
        '-stars_count', 'full_name'
    ).first()

    if not top_actor:
        return ''

    movies_starred_in = Movie.objects.filter(starring_actor=top_actor)

    if not movies_starred_in:
        return ''
    
    movies_avg_rating = movies_starred_in.aggregate(avg_rating=Avg('rating'))['avg_rating']
    movie_titles = [m.title for m in movies_starred_in]
    
    return f'Top Actor: {top_actor.full_name}, starring in movies: {", ".join(movie_titles)}, movies average rating: {movies_avg_rating:.1f}'


def get_actors_by_movies_count(): # 05
    actors_by_movies = Actor.objects.prefetch_related('actor_movies').annotate(actr_movies=Count('actor_movies')).filter(
        actr_movies__gt=0
    ).order_by('-actr_movies', 'full_name')[:3]

    if not actors_by_movies:
        return ''

    result = [f"{actor.full_name}, participated in {actor.actr_movies} movies" for actor in actors_by_movies]    
    return '\n'.join(result)


def get_top_rated_awarded_movie(): # 05
    top_movie = Movie.objects.select_related('starring_actor').prefetch_related('actors').filter(is_awarded=True).order_by('-rating', 'title').first()
    
    if not top_movie:
        return ''
    
    top_movie_star_name = 'N/A' if top_movie.starring_actor is None else top_movie.starring_actor.full_name 

    cast = ', '.join([actor.full_name for actor in top_movie.actors.order_by('full_name')])

    return f'Top rated awarded movie: {top_movie.title}, rating: {top_movie.rating:.1f}. Starring actor: {top_movie_star_name}. Cast: {cast}.'



def increase_rating(): # 05

    query = Q(is_classic=True) & Q(rating__lte=9.9)
    movies_meeting_criteria = Movie.objects.filter(query)

    if not movies_meeting_criteria:
        return 'No ratings increased.'

    movies_meeting_criteria.update(rating=F('rating') + 0.1)

    return f'Rating increased for {movies_meeting_criteria.count()} movies.'


def get_directors_alternative_solution(search_name=None, search_nationality=None): # alternative solution
    # if search_name is not None and search_nationality is not None: directors = Director.objects.filter( Q(full_name__icontains=search_name) & Q(nationality__icontains=search_nationality) ) elif search_name is not None: directors = Director.objects.filter(full_name__icontains=search_name) elif search_nationality is not None: directors = Director.objects.filter(nationality__icontains=search_nationality) else: return ""

    # directors = directors.order_by('full_name')

    # if directors.exists(): director_info = "" for director in directors: director_info += f"Director: {director.full_name}, nationality: {director.nationality}, experience: {director.years_of_experience}\n" return director_info else: return ""
    pass


def get_top_director_alternative_solution(): # alternative solution 
    # top_director = Director.objects.annotate(num_of_movies=Count('movie')).order_by('-num_of_movies', 'full_name').first()

    # if top_director is not None: return f"Top Director: {top_director.full_name}, movies: {top_director.num_of_movies}" else: return ""
    pass


def get_top_actor_alternative_solution(): # alternative solution
    #     top_actor = Actor.objects.annotate(num_of_movies=Count('movie')).order_by('-num_of_movies', 'full_name').first()
    #     if top_actor is not None:
        
    #         movie_titles = top_actor.movie.values_list('title', flat=True)
        
    #         movies_avg_rating = top_actor.movie.aggregate(avg_rating=Avg('rating'))['avg_rating']
        
    #         movies_avg_rating = round(movies_avg_rating, 1)
        
    #         movie_titles_str = ', '.join(movie_titles)
        
    #         return f'Top Actor: {top_actor.full_name}, starring in movies: {movie_titles_str}, movies average rating: {movies_avg_rating}'
        
    #     else: return ""
    pass


def create_actor(): # misc

    # Actor.objects.create(
    #     full_name='Christian Bale',
    #     birth_date='1974-01-30',
    #     nationality='British'
    # )

    # actor1 = Actor.objects.first()
    # print(actor1.full_name)
    # print(actor1.is_awarded)
    # actor1.is_awarded=False
    # actor1.save()
    # actor1.is_awarded
    pass

